package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AdminDAO;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String uname=request.getParameter("username");
		String pwd=request.getParameter("password");
		if(uname.equals("shivi_123")&&pwd.equals("12345"))
		{
			out.println("<html>");
			out.println("<title>Home</title>");
			out.println("<body>");
			out.println("<body bgcolor='#FFFFCC'>");
			out.println("<center></br></center>");
			out.println("<center><h1>Welcome to Website!!</h1></center>");
			out.println("<center></br></center>");
			out.println("<center></br></center>");
			out.println("<center></br></center>");
			out.println("<center><a href=\"add.jsp\" class=\"btn btn-lg btn-dark\">ADD</a></center>");
			out.println("<center></br></center>");
			out.println("<center><a href=\"delete.jsp\" class=\"btn btn-lg btn-dark\">DELETE</a></center>");
			out.println("<center></br></center>");
			out.println("<center><a href=\"admin.html\" class=\"btn btn-lg btn-dark\">BACK</a></center>");
			out.println("</body>");
			out.println("</html>");
			//response.sendRedirect("AdminHome");
			//RequestDispatcher rd=request.getRequestDispatcher("AdminHome");
			//rd.forward(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("admin.html");
			rd.include(request, response);
			out.println("<center><b><font color=red size=6>Invalid id and password</b></font></center>");

		}
	}

}
