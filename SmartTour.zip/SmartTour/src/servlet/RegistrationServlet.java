package servlet;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import dto.UserDTO;
import dao.UserDAO;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserDTO details = new UserDTO(null, request.getParameter("firstName"), request.getParameter("lastName"),
				request.getParameter("emailAddress"), request.getParameter("password"), request.getParameter("mobile"));
		new UserDAO().saveUserDTO(details);
		UserDTO userDetails = new UserDAO().checkUser(details.getEmailAddress());
		if (userDetails != null) {
			response.sendRedirect("/SmartTour/smarttour.html?id=" + userDetails.getId());
		} else {
			response.sendRedirect("/SmartTour/registration.html");
		}
	}

}
