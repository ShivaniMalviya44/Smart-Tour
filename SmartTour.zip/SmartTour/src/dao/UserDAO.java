package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBUtil;
import dto.UserDTO;

public class UserDAO {

	
	private final String checkDuplicate = "select id,firstName,lastName,emailAddress,password,mobile from userdetails where emailAddress=?";
	private final String insertQuery = "insert into userdetails(firstName,lastName,emailAddress,password,mobile) values(?,?,?,?,?)";
	private final String loginQuery = "select id,firstName,lastName,emailAddress,password,mobile from userdetails where emailAddress=? and password=?";
	
	public int saveUserDTO(UserDTO userDetails) {
		UserDTO details = checkUser(userDetails.getEmailAddress());
		if(details == null) {
			try(Connection connection = DBUtil.getMySQLConnection(); PreparedStatement prSt = connection.prepareStatement(insertQuery);){
				prSt.setString(1, userDetails.getFirstName());
				prSt.setString(2, userDetails.getLastName());
				prSt.setString(3, userDetails.getEmailAddress());
				prSt.setString(4, userDetails.getPassword());
				prSt.setString(5, userDetails.getMobile());
				return prSt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 0;
	}
	
	public UserDTO login(String emailAddress,String password){
		
		UserDTO userDetails =null;
		try(Connection connection = DBUtil.getMySQLConnection();PreparedStatement stmt = connection.prepareStatement(loginQuery)) {
			stmt.setString(1, emailAddress);
			stmt.setString(2, password);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()){
				userDetails = new UserDTO(rs.getInt("id"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("emailAddress"), rs.getString("password"),rs.getString("mobile"));
			}
			return userDetails;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public UserDTO checkUser(String emailAddress){
		UserDTO userDetails =null;
		try(Connection connection = DBUtil.getMySQLConnection();PreparedStatement stmt = connection.prepareStatement(checkDuplicate)) {
			stmt.setString(1, emailAddress);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()){
				userDetails = new UserDTO(rs.getInt("id"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("emailAddress"), rs.getString("password"),rs.getString("mobile"));
			}
			return userDetails;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}

