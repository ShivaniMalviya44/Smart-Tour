package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import util.DBUtil;
import dto.AdminDTO;


public class AdminDAO {
	
	private final String insertQuery = "insert into locations(name,address,lat,lng,city) values(?,?,?,?,?)";
	//private final String deleteQuery = "delete from locations where city=?";
	
public AdminDTO insertData(String name, String address, float lat, float lng, String city){
		
	AdminDTO userDetails =null;
		try(Connection connection = DBUtil.getMySQLConnection();PreparedStatement stmt = connection.prepareStatement(insertQuery)) {
			stmt.setString(1, name);
			stmt.setString(2, address);
			stmt.setFloat(3, lat);
			stmt.setFloat(4, lng);
			stmt.setString(5, city);
			stmt.executeUpdate();
			System.out.println("Inserted Successfully");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Opps!!! Insertion Error");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Opps!!! Insertion Error");
		}
		return null;
	}
	

}
